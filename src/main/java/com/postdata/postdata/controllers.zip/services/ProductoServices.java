package com.postdata.postdata.services;


import java.util.ArrayList;

import org.springframework.stereotype.Service;
import com.postdata.postdata.Producto;

@Service
public class ProductoServices {
	//definir productos //lista constante final
	public final ArrayList<Producto> lista = new ArrayList<Producto>();
	ProductoServices(){
		//lista Array.asList(new Producto(),new Producto(),new Producto());
		lista.add(new Producto("La estafa maestra: La historia del desfalco", 
				"Manuel Ureste Cava", "Planeta M�xico", 
				"9786070787126",
				"https://www.gandhi.com.mx/media/catalog/product/9/7/9786070787126_b19c.jpg",
				"La ma�ana del 13 de agosto de 2019, la historia pol�tica modernade M�xico cambi�. Por primera vez en nuestro pa�s, una secretaria de Estado era encarcelada a ra�z de una investigaci�n period�stica. Rosario Robles ingres� al penal de Santa Martha Acatitlaacusada de ejercicio indebido de la funci�n p�blica y, hasta lafecha, sigue presa. La Estafa Maestra �Premio Nacional de Periodismo 2017 y Premio Ortega y Gasset 2018� devel� el multimillonario desfalco de dinero p�blico bajo un esquema de corrupci�n que involucraba a miembros del gabinete del expresidente Pe�a Nieto, universidades p�blicas y empresas fantasma. De todos los altos mandos involucrados solo Robles, exsecretaria de la Sedesol y de la Sedatu y una vieja adversaria del presidente L�pez Obrador, ha sido encarcelada y paga un castigo que asoma oscuros motivos pol�ticos. A partir de entrevistas in�ditas, un minucioso seguimiento de la investigaci�n a tres a�os de la publicaci�n original y una implacable cobertura de los juicios, los periodistas Nayeli Rold�n y Manuel Ureste relatan, a manera de thriller pol�tico, la historia detr�s de La Estafa Maestra y dan a conocer a los orquestadores de uno de los peores desfalcos que M�xico ha conocido y cuya maquinaria contin�a intacta para seguir operando.", 268.00));
		lista.add(new Producto(
				"un nombre",
				"un autor",
				"una editorial",
				"9786070787126",
				"Una url",
				"una descrp",
				126)
				);
	}//bob
	public ArrayList<Producto> getProductos(){
		return lista;
	}
	public Producto getProducto(Long id) {
		Producto tmpProd = null;
		for (Producto producto : lista) {
			if(producto.getId()==id) {
				tmpProd=producto;
				break;
			}
		}//foreach
		return tmpProd;
	}//getProducto
	
	
	
	public Producto deleteProducto(Long id) {
		Producto tmpProd = null;
		for (Producto producto : lista) {
			if(producto.getId()==id) {
				tmpProd=lista.remove(lista.indexOf(producto));
				break;
			}
		}//foreach
		return tmpProd;
	}//deleteProducto
	public Producto addProducto(Producto producto) {
		lista.add(producto);
		return producto;
	}
	public Producto updateProducto(Long id, String nombre,String autor, 
			String editorial, String ISBN, String URL_imagen,String descripcion, double precio) {
		Producto tmpProd = null;
		for(Producto producto : lista) {
			if(producto.getId()==id) {
				if(nombre!=null)producto.setNombre(nombre);
				if(autor!=null)producto.setAutor(autor);
				if(editorial!=null)producto.setEditorial(editorial);
				if(ISBN!=null)producto.setISBN(ISBN);
				if(URL_imagen!=null)producto.setURL_imagen(URL_imagen);
				if(descripcion!=null)producto.setDescripcion(descripcion);
				if(precio>0)producto.setPrecio((double)precio);
				tmpProd = producto;
				break;
			}
		}
		return null;
	}
	
}//class ProductoServices