package com.postdata.postdata.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.postdata.postdata.Producto;
import com.postdata.postdata.services.ProductoServices;
@RestController
@RequestMapping (path="/api/products")
@CrossOrigin(origins = "*")
public class ProductoController {
private final ProductoServices productoServices;
	
	@Autowired
	public ProductoController(ProductoServices productoServices) {
	this.productoServices = productoServices;
	}//constructor


	@GetMapping
	public List<Producto> getAllProducts() {
		return productoServices.getProductos();
	}//getAllProducts
	
	@GetMapping (path="{prodId}")
	public Producto getProduct(@PathVariable("prodId")Long id) {
		return productoServices.getProducto(id);
	}
	
	@DeleteMapping (path="{prodId}")
	public Producto deleteProduct(@PathVariable("prodId")Long id) {
		return productoServices.deleteProducto(id);
	}
	@PostMapping
	public Producto addProduct(@RequestBody Producto producto) {
		return productoServices.addProducto(producto);
	}
	@PutMapping (path="{prodId}")
	public Producto updateProduct (@PathVariable("prodId") Long id,
			@RequestParam String nombre,
			@RequestParam String autor,
			@RequestParam String editorial,
			@RequestParam String ISBN,
			@RequestParam String URL_imagen,
			@RequestParam String descripcion,
			@RequestParam double precio) {
		return productoServices.updateProducto(id, nombre,
				autor, editorial, ISBN, URL_imagen,descripcion,precio);
	}
}
