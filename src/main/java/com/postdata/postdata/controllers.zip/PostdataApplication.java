package com.postdata.postdata;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostdataApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostdataApplication.class, args);
	}

}
